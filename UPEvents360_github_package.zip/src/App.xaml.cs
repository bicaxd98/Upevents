using System.Windows;

namespace Gopro360App
{
    public partial class App : Application { }
}
